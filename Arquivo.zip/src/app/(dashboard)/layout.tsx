'use client'

import { Sidebar } from '@/components/layout/Sidebar'
import { Header } from '@/components/layout/Header'
import { OnboardingModal } from '@/components/onboarding/OnboardingModal'
import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { createClient } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [showOnboarding, setShowOnboarding] = useState(false)
  const [authChecked, setAuthChecked] = useState(false)

  const checkAuth = useCallback(async () => {
    try {
      const supabase = createClient()

      // Tenta refresh da sessão antes de verificar
      const { error: refreshError } = await supabase.auth.refreshSession()
      
      const { data: { user } } = await supabase.auth.getUser()

      // Sem usuário válido → manda pro login
      if (!user) {
        router.replace('/login')
        return
      }

      // Verifica onboarding
      const { data: profile } = await supabase
        .from('profiles')
        .select('onboarding_done')
        .eq('id', user.id)
        .single()

      if (!profile || !profile.onboarding_done) {
        setShowOnboarding(true)
      }

      setAuthChecked(true)
    } catch (err) {
      console.error('Auth check failed:', err)
      router.replace('/login')
    }
  }, [router])

  useEffect(() => {
    checkAuth()

    // Escuta mudanças de sessão em tempo real
    const supabase = createClient()
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_OUT' || (!session && event !== 'INITIAL_SESSION')) {
        router.replace('/login')
      }
    })

    return () => subscription.unsubscribe()
  }, [checkAuth])

  function handleOnboardingComplete() {
  setShowOnboarding(false)
  router.refresh() // remonta a página e o tour dispara de novo
}

  // Enquanto não confirmou auth, não renderiza nada (evita flash de conteúdo)
  if (!authChecked) {
    return (
      <div
        className="flex h-screen items-center justify-center"
        style={{ background: '#0a0a0f' }}
      >
        <div
          className="w-6 h-6 rounded-full border-2 border-t-transparent animate-spin"
          style={{ borderColor: '#7c6ef7', borderTopColor: 'transparent' }}
        />
      </div>
    )
  }

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: '#0a0a0f' }}>
      {/* Sidebar - só desktop */}
      <div className="hidden md:flex">
        <Sidebar />
      </div>

      {/* Drawer mobile */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-40 md:hidden"
              style={{ background: 'rgba(0,0,0,0.75)' }}
              onClick={() => setMobileMenuOpen(false)}
            />
            <motion.div
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ duration: 0.25, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="fixed left-0 top-0 bottom-0 z-50 md:hidden"
            >
              <Sidebar onClose={() => setMobileMenuOpen(false)} />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Header onMenuClick={() => setMobileMenuOpen(true)} />
        <main className="flex-1 overflow-y-auto p-4 md:p-6" style={{ background: '#0a0a0f' }}>
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>

      {/* Onboarding */}
      <AnimatePresence>
        {showOnboarding && (
          <OnboardingModal onComplete={handleOnboardingComplete} />
        )}
      </AnimatePresence>
    </div>
  )
}
